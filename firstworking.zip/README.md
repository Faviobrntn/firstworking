# Firstworking
=============================

Es un mini proyecto sobre una bolsa de trabajo

---------------

Instalacion
---------------

#### <i class="icon-hdd"></i> Clonar el proyecto

Una vez clonado, si estas en localhost configurar la constante *APPNAME* ubicada en */htdocs/nombre_del_proyecto/config/constantes.php*, asignarle el *nombre_del_proyecto*.

Y eso es todo.

Saludos.