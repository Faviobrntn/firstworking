<?php 

class Conexion
{
    public $host = 'localhost';
    public $user = 'root';
    public $pass = '';
    public $database = 'firstworking';
}


?>